// index.js
import React, { useState, useEffect } from "react";

function App() {
  // Authentication state
  const [isAdmin, setIsAdmin] = useState(false);
  const [password, setPassword] = useState("");

  // Content state
  const [title, setTitle] = useState("Sommerville Masters Pool");
  const [logoUrl, setLogoUrl] = useState("");
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [newsContent, setNewsContent] = useState(
    "The tournament is in full swing with exciting matches and close competition."
  );
  const [statusContent, setStatusContent] = useState(
    "Round 3 completed. Final round begins tomorrow at 8:00 AM."
  );

  // Data state
  const [professionalPlayers, setProfessionalPlayers] = useState([
    {
      id: 1,
      name: "Tiger Woods",
      round1: 72,
      round2: 68,
      round3: 70,
      round4: 69,
      total: 279,
      toPar: -9,
    },
    {
      id: 2,
      name: "Rory McIlroy",
      round1: 71,
      round2: 70,
      round3: 68,
      round4: 70,
      total: 279,
      toPar: -9,
    },
    {
      id: 3,
      name: "Scottie Scheffler",
      round1: 69,
      round2: 72,
      round3: 71,
      round4: 68,
      total: 280,
      toPar: -8,
    },
  ]);
  const [participants, setParticipants] = useState([
    {
      id: 1,
      name: "John Doe",
      selectedPlayers: [1, 2, 3, 1, 2, 3],
      totalToPar: -34,
    },
    {
      id: 2,
      name: "Jane Smith",
      selectedPlayers: [2, 3, 1, 2, 3, 1],
      totalToPar: -32,
    },
  ]);
  const [summaryImages, setSummaryImages] = useState([
    {
      id: 1,
      url: "https://images.unsplash.com/photo-1506744038136-46273834b3fb",
      alt: "Golf course view",
    },
    {
      id: 2,
      url: "https://images.unsplash.com/photo-1520962910844-0f05b0aab2c4",
      alt: "Leaderboard snapshot",
    },
  ]);

  // Editing state
  const [editingPlayer, setEditingPlayer] = useState(null);
  const [editingParticipant, setEditingParticipant] = useState(null);
  const [showAddParticipantModal, setShowAddParticipantModal] = useState(false);
  const [newParticipantName, setNewParticipantName] = useState("");
  const [newParticipantSelections, setNewParticipantSelections] = useState([]);
  const [newImageUrl, setNewImageUrl] = useState("");
  const [newImageAlt, setNewImageAlt] = useState("");

  // Calculate participant totals
  const calculateParticipantTotals = (participants) => {
    return participants.map((participant) => {
      const scores = participant.selectedPlayers.map((id) => {
        const p = professionalPlayers.find((p) => p.id === id);
        return p ? p.toPar : 0;
      });
      const sortedScores = [...scores].sort((a, b) => a - b);
      const lowestFour = sortedScores.slice(0, 4);
      const totalToPar = lowestFour.reduce((a, b) => a + b, 0);
      return { ...participant, totalToPar };
    });
  };

  const [calculatedParticipants, setCalculatedParticipants] = useState(
    calculateParticipantTotals(participants)
  );

  useEffect(() => {
    setCalculatedParticipants(calculateParticipantTotals(participants));
  }, [participants, professionalPlayers]);

  // Image slideshow
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImageIndex((prev) => (prev + 1) % summaryImages.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [summaryImages.length]);

  // Admin login/logout
  const handleAdminLogin = () => {
    if (password === "admin123") {
      setIsAdmin(true);
      setPassword("");
    } else {
      alert('Incorrect password. Try "admin123"');
    }
  };
  const handleAdminLogout = () => {
    setIsAdmin(false);
    setPassword("");
  };

  // Player functions
  const calculateTotal = (player) =>
    player.round1 + player.round2 + player.round3 + player.round4;
  const calculateToPar = (total) => 288 - total; // assuming par 72 per round

  const startEditPlayer = (player) => setEditingPlayer({ ...player });
  const savePlayerEdit = () => {
    if (editingPlayer) {
      const updated = {
        ...editingPlayer,
        total: calculateTotal(editingPlayer),
        toPar: calculateToPar(calculateTotal(editingPlayer)),
      };
      setProfessionalPlayers((players) =>
        players.map((p) => (p.id === updated.id ? updated : p))
      );
      setEditingPlayer(null);
    }
  };
  const addNewPlayer = () => {
    const id = Math.max(0, ...professionalPlayers.map((p) => p.id)) + 1;
    const newPlayer = {
      id,
      name: `New Player ${id}`,
      round1: 72,
      round2: 72,
      round3: 72,
      round4: 72,
      total: 288,
      toPar: 0,
    };
    setProfessionalPlayers([...professionalPlayers, newPlayer]);
  };
  const removePlayer = (id) => {
    setProfessionalPlayers((players) => players.filter((p) => p.id !== id));
  };

  // Participant functions
  const startEditParticipant = (participant) =>
    setEditingParticipant({ ...participant });
  const saveParticipantEdit = () => {
    if (editingParticipant) {
      setParticipants((p) =>
        p.map((pp) =>
          pp.id === editingParticipant.id ? editingParticipant : pp
        )
      );
      setEditingParticipant(null);
    }
  };
  const togglePlayerSelection = (id) => {
    setNewParticipantSelections((prev) => {
      if (prev.includes(id)) {
        return prev.filter((pid) => pid !== id);
      } else if (prev.length < 6) {
        return [...prev, id];
      }
      return prev;
    });
  };
  const toggleEditPlayerSelection = (id) => {
    if (editingParticipant) {
      setEditingParticipant((prev) => {
        if (!prev) return null;
        const includes = prev.selectedPlayers.includes(id);
        const newSelections = includes
          ? prev.selectedPlayers.filter((pid) => pid !== id)
          : [...prev.selectedPlayers, id];
        if (newSelections.length > 6) return prev; // limit
        return { ...prev, selectedPlayers: newSelections };
      });
    }
  };
  const addNewParticipant = () => {
    if (newParticipantName && newParticipantSelections.length === 6) {
      const id = Math.max(0, ...participants.map((p) => p.id)) + 1;
      setParticipants([
        ...participants,
        {
          id,
          name: newParticipantName,
          selectedPlayers: newParticipantSelections,
          totalToPar: 0,
        },
      ]);
      setNewParticipantName("");
      setNewParticipantSelections([]);
      setShowAddParticipantModal(false);
    }
  };
  const removeParticipant = (id) => {
    setParticipants((p) => p.filter((pp) => pp.id !== id));
  };

  // Image management
  const addNewImage = () => {
    if (newImageUrl && newImageAlt) {
      const id = Math.max(0, ...summaryImages.map((i) => i.id)) + 1;
      setSummaryImages([
        ...summaryImages,
        { id, url: newImageUrl, alt: newImageAlt },
      ]);
      setNewImageUrl("");
      setNewImageAlt("");
    }
  };
  const removeImage = (id) => {
    setSummaryImages((images) => images.filter((i) => i.id !== id));
  };

  // Utility: calculate participant's total to par
  const getParticipantScore = (participant) => {
    const scores = participant.selectedPlayers.map((id) => {
      const p = professionalPlayers.find((p) => p.id === id);
      return p ? p.toPar : 0;
    });
    const lowestFour = [...scores].sort((a, b) => a - b).slice(0, 4);
    return lowestFour.reduce((a, b) => a + b, 0);
  };

  return (
    <div className="min-h-screen bg-green-50 font-sans">
      {/* Header */}
      <header className="bg-green-800 text-white shadow-md">
        <div className="max-w-7xl mx-auto flex items-center justify-between p-4">
          <div className="flex items-center space-x-2">
            {logoUrl ? (
              <img src={logoUrl} className="w-16 h-16 object-contain" />
            ) : (
              <div className="w-16 h-16 bg-white border-2 border-dashed rounded-xl flex items-center justify-center">
                <svg
                  className="w-8 h-8 text-gray-400"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth={2}
                  viewBox="0 0 24 24"
                >
                  <path d="M12 2l9 21H3L12 2z" />
                </svg>
              </div>
            )}
            <h1 className="text-2xl font-bold">{title}</h1>
          </div>
          {!isAdmin ? (
            <div className="flex items-center space-x-2">
              <input
                type="password"
                placeholder="Admin password"
                className="p-2 border border-gray-300 rounded"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
              <button
                className="bg-green-700 hover:bg-green-600 px-3 py-1 rounded flex items-center space-x-2"
                onClick={handleAdminLogin}
              >
                <svg
                  className="w-4 h-4"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth={2}
                  viewBox="0 0 24 24"
                >
                  <path d="M12 11c0-1.1-.9-2-2-2s-2 .9-2 2 .9 2 2 2 2-.9 2-2z" />
                  <path d="M19 15v-4a2 2 0 00-2-2H7a2 2 0 00-2 2v4" />
                  <path d="M12 19v2" />
                </svg>
                <span>Admin</span>
              </button>
            </div>
          ) : (
            <button
              className="bg-red-600 hover:bg-red-500 px-3 py-1 rounded"
              onClick={handleAdminLogout}
            >
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                strokeWidth={2}
                viewBox="0 0 24 24"
              >
                <path d="M6 18L18 6M6 6l12 12" />
              </svg>
              Logout
            </button>
          )}
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto p-4">
        {/* Tournament Summary */}
        <div className="bg-white rounded shadow mb-8 p-4">
          <h2 className="text-xl font-semibold mb-4">Tournament Summary</h2>
          <div className="grid md:grid-cols-2 gap-4">
            {/* Image slideshow */}
            <div className="relative h-64 overflow-hidden rounded border-2 border-dashed flex items-center justify-center bg-gray-200">
              {summaryImages.length > 0 && (
                <img
                  src={summaryImages[currentImageIndex].url}
                  alt={summaryImages[currentImageIndex].alt}
                  className="absolute inset-0 w-full h-full object-cover transition-opacity duration-1000"
                />
              )}
            </div>
            {/* News & Status */}
            <div>
              <h3 className="font-semibold mb-2">Latest News</h3>
              <p className="mb-4">{newsContent}</p>
              <h3 className="font-semibold mb-2">Current Status</h3>
              <p>{statusContent}</p>
            </div>
          </div>
        </div>

        {/* Participant Leaderboard */}
        <div className="bg-white rounded shadow mb-8 p-4">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold">Participant Leaderboard</h2>
            {isAdmin && (
              <button
                className="bg-green-700 hover:bg-green-600 px-3 py-1 rounded flex items-center space-x-2"
                onClick={() => setShowAddParticipantModal(true)}
              >
                <svg
                  className="w-4 h-4"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth={2}
                  viewBox="0 0 24 24"
                >
                  <path d="M12 4v16m8-8H4" />
                </svg>
                <span>Add Participant</span>
              </button>
            )}
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full border-collapse border border-gray-300">
              <thead className="bg-green-600 text-white">
                <tr>
                  <th className="border border-gray-300 px-3 py-2 text-left text-sm uppercase">
                    Name
                  </th>
                  <th className="border border-gray-300 px-3 py-2 text-left text-sm uppercase">
                    Selected Players
                  </th>
                  <th className="border border-gray-300 px-3 py-2 text-left text-sm uppercase">
                    Total To Par
                  </th>
                  {isAdmin && (
                    <th className="border border-gray-300 px-3 py-2 text-left text-sm uppercase">
                      Actions
                    </th>
                  )}
                </tr>
              </thead>
              <tbody>
                {calculatedParticipants.map((p) => (
                  <tr key={p.id} className="border-b border-gray-200">
                    <td className="border border-gray-300 px-3 py-2 text-sm">
                      {editingParticipant?.id === p.id ? (
                        <input
                          className="w-full border border-gray-300 rounded p-1"
                          value={editingParticipant.name}
                          onChange={(e) =>
                            setEditingParticipant({
                              ...editingParticipant,
                              name: e.target.value,
                            })
                          }
                        />
                      ) : (
                        p.name
                      )}
                    </td>
                    <td className="border border-gray-300 px-3 py-2 text-sm">
                      {editingParticipant?.id === p.id ? (
                        <div className="flex flex-wrap gap-1">
                          {professionalPlayers.map((player) => (
                            <button
                              key={player.id}
                              className={`px-2 py-1 rounded border ${
                                editingParticipant.selectedPlayers.includes(
                                  player.id
                                )
                                  ? "bg-green-100 border-green-500"
                                  : "border-gray-300 hover:bg-gray-100"
                              }`}
                              onClick={() =>
                                toggleEditPlayerSelection(player.id)
                              }
                              disabled={
                                !editingParticipant.selectedPlayers.includes(
                                  player.id
                                ) &&
                                editingParticipant.selectedPlayers.length >= 6
                              }
                            >
                              {player.name}
                            </button>
                          ))}
                        </div>
                      ) : (
                        p.selectedPlayers
                          .map(
                            (id) =>
                              professionalPlayers.find((pp) => pp.id === id)
                                ?.name || "Unknown"
                          )
                          .join(", ")
                      )}
                    </td>
                    <td className="border border-gray-300 px-3 py-2 text-sm">
                      {p.totalToPar}
                    </td>
                    {isAdmin && (
                      <td className="border border-gray-300 px-3 py-2 flex space-x-2 text-sm">
                        {editingParticipant?.id === p.id ? (
                          <>
                            <button
                              className="bg-green-700 hover:bg-green-600 px-2 py-1 rounded"
                              onClick={saveParticipantEdit}
                            >
                              ✓
                            </button>
                            <button
                              className="border border-gray-400 px-2 py-1 rounded"
                              onClick={() => setEditingParticipant(null)}
                            >
                              ✗
                            </button>
                          </>
                        ) : (
                          <>
                            <button
                              className="border border-gray-400 px-2 py-1 rounded"
                              onClick={() => startEditParticipant(p)}
                            >
                              ✎
                            </button>
                            <button
                              className="border border-red-500 px-2 py-1 rounded"
                              onClick={() => removeParticipant(p.id)}
                            >
                              🗑️
                            </button>
                          </>
                        )}
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Professional Leaderboard */}
        <div className="bg-white rounded shadow mb-8 p-4">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold">Professional Leaderboard</h2>
            {isAdmin && (
              <button
                className="bg-green-700 hover:bg-green-600 px-3 py-1 rounded flex items-center space-x-2"
                onClick={addNewPlayer}
              >
                <svg
                  className="w-4 h-4"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth={2}
                  viewBox="0 0 24 24"
                >
                  <path d="M12 4v16m8-8H4" />
                </svg>
                <span>Add Player</span>
              </button>
            )}
          </div>
          <div className="overflow-x-auto max-h-96 overflow-y-auto">
            <table className="min-w-full border-collapse border border-gray-300 sticky top-0 bg-white">
              <thead className="bg-green-600 text-white sticky top-0">
                <tr>
                  <th className="border border-gray-300 px-3 py-2 text-left text-sm uppercase">
                    Player
                  </th>
                  <th className="border border-gray-300 px-3 py-2 text-left text-sm uppercase">
                    Round 1
                  </th>
                  <th className="border border-gray-300 px-3 py-2 text-left text-sm uppercase">
                    Round 2
                  </th>
                  <th className="border border-gray-300 px-3 py-2 text-left text-sm uppercase">
                    Round 3
                  </th>
                  <th className="border border-gray-300 px-3 py-2 text-left text-sm uppercase">
                    Round 4
                  </th>
                  <th className="border border-gray-300 px-3 py-2 text-left text-sm uppercase">
                    Total
                  </th>
                  <th className="border border-gray-300 px-3 py-2 text-left text-sm uppercase">
                    To Par
                  </th>
                  {isAdmin && (
                    <th className="border border-gray-300 px-3 py-2 text-left text-sm uppercase">
                      Actions
                    </th>
                  )}
                </tr>
              </thead>
              <tbody>
                {professionalPlayers.map((player) => (
                  <tr key={player.id} className="border-b border-gray-200">
                    <td className="border border-gray-300 px-3 py-2 text-sm">
                      {player.name}
                    </td>
                    {["round1", "round2", "round3", "round4"].map(
                      (field, idx) => (
                        <td
                          key={field}
                          className="border border-gray-300 px-3 py-2 text-sm"
                        >
                          {editingPlayer?.id === player.id ? (
                            <input
                              type="number"
                              className="w-20 border border-gray-300 rounded p-1"
                              value={editingPlayer[field]}
                              onChange={(e) =>
                                setEditingPlayer({
                                  ...editingPlayer,
                                  [field]: parseInt(e.target.value) || 0,
                                })
                              }
                            />
                          ) : (
                            player[field]
                          )}
                        </td>
                      )
                    )}
                    <td className="border border-gray-300 px-3 py-2 text-sm">
                      {player.total}
                    </td>
                    <td className="border border-gray-300 px-3 py-2 text-sm">
                      {player.toPar}
                    </td>
                    {isAdmin && (
                      <td className="border border-gray-300 px-3 py-2 flex space-x-2 text-sm">
                        {editingPlayer?.id === player.id ? (
                          <>
                            <button
                              className="bg-green-700 hover:bg-green-600 px-2 py-1 rounded"
                              onClick={savePlayerEdit}
                            >
                              ✓
                            </button>
                            <button
                              className="border border-gray-400 px-2 py-1 rounded"
                              onClick={() => setEditingPlayer(null)}
                            >
                              ✗
                            </button>
                          </>
                        ) : (
                          <>
                            <button
                              className="border border-gray-400 px-2 py-1 rounded"
                              onClick={() => startEditPlayer(player)}
                            >
                              ✎
                            </button>
                            <button
                              className="border border-red-500 px-2 py-1 rounded"
                              onClick={() => removePlayer(player.id)}
                            >
                              🗑️
                            </button>
                          </>
                        )}
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Add Participant Modal */}
      {showAddParticipantModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg max-w-md w-full p-4 shadow-lg">
            <h3 className="text-lg font-semibold mb-4">Add New Participant</h3>
            <div className="mb-4">
              <label className="block mb-1 font-semibold">Name</label>
              <input
                className="w-full border border-gray-300 rounded p-2"
                value={newParticipantName}
                onChange={(e) => setNewParticipantName(e.target.value)}
                placeholder="Participant Name"
              />
            </div>
            <div>
              <label className="block mb-1 font-semibold">
                Select 6 Players
              </label>
              <div className="grid grid-cols-2 gap-2 max-h-64 overflow-y-auto border p-2 rounded">
                {professionalPlayers.map((player) => (
                  <div
                    key={player.id}
                    className={`p-2 rounded cursor-pointer ${
                      newParticipantSelections.includes(player.id)
                        ? "bg-green-100 border border-green-500"
                        : "hover:bg-gray-100"
                    }`}
                    onClick={() => togglePlayerSelection(player.id)}
                  >
                    <div className="flex items-center">
                      <input
                        type="checkbox"
                        checked={newParticipantSelections.includes(player.id)}
                        readOnly
                        className="mr-2"
                      />
                      <span>
                        {player.name} ({player.toPar})
                      </span>
                    </div>
                  </div>
                ))}
              </div>
              <p className="text-sm text-gray-600 mt-2">
                Selected: {newParticipantSelections.length}/6
              </p>
            </div>
            <div className="flex justify-end space-x-2 mt-4">
              <button
                className="px-4 py-2 border border-gray-400 rounded"
                onClick={() => setShowAddParticipantModal(false)}
              >
                Cancel
              </button>
              <button
                className="px-4 py-2 bg-green-700 text-white rounded disabled:opacity-50"
                onClick={addNewParticipant}
                disabled={
                  !newParticipantName || newParticipantSelections.length !== 6
                }
              >
                Add Participant
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Admin Panel */}
      {isAdmin && (
        <div className="max-w-4xl mx-auto p-4 mt-8 border border-red-500 rounded bg-red-50 shadow-md">
          <h3 className="text-lg font-semibold mb-4 text-red-700">
            Admin Panel
          </h3>
          <div className="grid md:grid-cols-2 gap-4">
            {/* Content Management */}
            <div>
              <h4 className="font-semibold mb-2">Content Management</h4>
              <div className="mb-2">
                <label className="block mb-1 font-semibold">Title</label>
                <input
                  className="w-full border border-gray-300 rounded p-2"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                />
              </div>
              <div className="mb-2">
                <label className="block mb-1 font-semibold">Logo URL</label>
                <input
                  className="w-full border border-gray-300 rounded p-2"
                  value={logoUrl}
                  onChange={(e) => setLogoUrl(e.target.value)}
                  placeholder="Enter logo image URL"
                />
              </div>
              <div className="mb-2">
                <label className="block mb-1 font-semibold">News Content</label>
                <textarea
                  className="w-full border border-gray-300 rounded p-2"
                  rows={3}
                  value={newsContent}
                  onChange={(e) => setNewsContent(e.target.value)}
                />
              </div>
              <div className="mb-2">
                <label className="block mb-1 font-semibold">
                  Status Content
                </label>
                <textarea
                  className="w-full border border-gray-300 rounded p-2"
                  rows={2}
                  value={statusContent}
                  onChange={(e) => setStatusContent(e.target.value)}
                />
              </div>
            </div>
            {/* Image Management */}
            <div>
              <h4 className="font-semibold mb-2">Image Management</h4>
              <div className="mb-2">
                <label className="block mb-1 font-semibold">
                  Add New Image
                </label>
                <input
                  className="w-full border border-gray-300 rounded p-2 mb-1"
                  placeholder="Image URL"
                  value={newImageUrl}
                  onChange={(e) => setNewImageUrl(e.target.value)}
                />
                <input
                  className="w-full border border-gray-300 rounded p-2 mb-2"
                  placeholder="Image Description"
                  value={newImageAlt}
                  onChange={(e) => setNewImageAlt(e.target.value)}
                />
                <button
                  className="w-full bg-green-700 hover:bg-green-600 text-white px-3 py-2 rounded disabled:opacity-50"
                  onClick={addNewImage}
                  disabled={!newImageUrl || !newImageAlt}
                >
                  <svg
                    className="w-4 h-4 inline-block mr-2"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth={2}
                    viewBox="0 0 24 24"
                  >
                    <path d="M12 4v16m8-8H4" />
                  </svg>
                  Add Image
                </button>
              </div>
              <div>
                <label className="block mb-1 font-semibold">
                  Current Images
                </label>
                <div className="max-h-40 overflow-y-auto border p-2 rounded space-y-2">
                  {summaryImages.map((img) => (
                    <div
                      key={img.id}
                      className="flex justify-between items-center p-2 border rounded"
                    >
                      <div className="truncate">{img.alt}</div>
                      <button
                        className="text-red-500"
                        onClick={() => removeImage(img.id)}
                      >
                        ✖
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="bg-green-800 text-white text-center p-4 mt-8">
        © 2023 Sommerville Masters Pool. All rights reserved.
      </footer>
    </div>
  );
}

// Render
export default App;
